var Difficulty;
(function (Difficulty) {
    Difficulty[Difficulty["Easy"] = 4] = "Easy";
    Difficulty[Difficulty["Normal"] = 6] = "Normal";
    Difficulty[Difficulty["Hard"] = 8] = "Hard";
})(Difficulty || (Difficulty = {}));
let allCards = [
    'fa-php', 'fa-php',
    'fa-github', 'fa-github',
    'fa-java', 'fa-java',
    'fa-python', 'fa-python',
    'fa-docker', 'fa-docker',
    'fa-wordpress', 'fa-wordpress',
    'fa-jedi-order', 'fa-jedi-order',
    'fa-stack-overflow', 'fa-stack-overflow',
];
let cards = [];
let flippedCards = [];
//DIFFICULTY
let pairCount = 6;
let difficulty = Difficulty.Normal;
const difficulties = {
    difEasy: Difficulty.Easy,
    difNormal: Difficulty.Normal,
    difHard: Difficulty.Hard
};
document.getElementById("difNormal").classList.add("btn-primary");
//DIFFICULTY CLICKS
document.getElementById("difficulty").addEventListener("click", function (event) {
    const target = event.target;
    const button = target.closest("button");
    if (!button)
        return; // damit nicht klick auf div
    if (matchCounter > 0 || moveTracker > 0) {
        alert("You already started a game! Please start a new game to change the difficulty.");
        return;
    }
    document.querySelectorAll("#difficulty button").forEach(btn => btn.classList.remove("btn-primary"));
    button.classList.add("btn-primary");
    difficulty = difficulties[button.id] || Difficulty.Normal;
    pairCount = difficulty;
    const input = document.getElementById("pairInput");
    if (input)
        input.value = String(pairCount);
    highscoreKey = "memoryHighscore_" + difficulty;
    highscore = Number(localStorage.getItem(highscoreKey)) || 0;
    highscoreMessage.textContent = "Highscore: " + highscore;
    setupGame();
});
//INPUT ÜBERSCHREIBT DIFFICUTLY
document.getElementById("pairInput")
    .addEventListener("input", (e) => {
    let value = Number(e.target.value);
    const maxPairs = allCards.length / 2;
    if (value < 2)
        value = 2;
    if (value > maxPairs)
        value = maxPairs;
    pairCount = value;
});
//KARTEN WERDEN GEMISCHT
function shuffle(cards) {
    cards.sort(() => Math.random() - 0.5);
}
//KARTEN ERSTELLEN
const gameboard = document.getElementById("game-board");
function setupGame() {
    gameboard.innerHTML = "";
    const input = document.getElementById("pairInput");
    pairCount = Number(input.value);
    cards = allCards.slice(0, pairCount * 2); //kopiert + kürzt
    shuffle(cards);
    console.log(cards);
    cards.forEach(symbol => {
        const card = document.createElement("div"); //card
        card.classList.add('card');
        card.dataset.symbol = symbol;
        card.addEventListener('click', flipCard);
        gameboard.appendChild(card);
    });
}
// MESSAGES und TRACKER
let winningMessage = document.getElementById("winningMessage");
let matchesMessage = document.getElementById("matchesMessage");
let moveMessage = document.getElementById("moveMessage");
let highscoreMessage = document.getElementById("highscoreMessage");
let highscoreKey = "memoryHighscore_" + difficulty;
let highscore = Number(localStorage.getItem(highscoreKey)) || 0;
highscoreMessage.textContent = "Highscore: " + highscore;
const currentPlayerUI = document.getElementById("currentPlayer");
const scoreP1UI = document.getElementById("scoreP1");
const scoreP2UI = document.getElementById("scoreP2");
let checkMatchProcess = 0;
let moveTracker = 0;
let matchCounter = 0;
//MULTIPLAYER
let multiplayer = false;
let currentPlayer = 1;
let scoreP1 = 0;
let scoreP2 = 0;
//MULTIPLAYER TOGGLE
document.getElementById("toggleMultiplayer")
    .addEventListener("click", () => {
    multiplayer = !multiplayer;
    resetGame();
    if (!multiplayer) {
        currentPlayerUI.textContent = "Singleplayer Mode";
    }
    else {
        currentPlayerUI.textContent = "Player 1";
    }
});
//KARTE WIRD UMGEDREHT
function flipCard(event) {
    if (checkMatchProcess !== 0)
        return;
    const card = event.currentTarget;
    if (card.classList.contains("flipped") ||
        card.classList.contains("matched")) {
        return;
    }
    card.classList.add("flipped");
    card.innerHTML = `<i class="fa-brands ${card.dataset.symbol}"></i>`;
    flippedCards.push(card);
    if (flippedCards.length >= 2) {
        checkMatchProcess = 1;
        checkMatch();
    }
}
//MATCH WIRD GECHWECKT
function checkMatch() {
    moveTracker++;
    moveMessage.textContent = moveTracker + " Moves";
    const symbol1 = flippedCards[0]?.dataset.symbol;
    const symbol2 = flippedCards[1]?.dataset.symbol;
    if (symbol1 && symbol2 && symbol1 === symbol2) {
        if (flippedCards[0]) {
            flippedCards[0].classList.remove("flipped");
            flippedCards[0].classList.add("matched");
        }
        if (flippedCards[1]) {
            flippedCards[1].classList.remove("flipped");
            flippedCards[1].classList.add("matched");
        }
        // MULTIPLAYER SCORE
        if (multiplayer) {
            if (currentPlayer === 1)
                scoreP1++;
            else
                scoreP2++;
            updateScores();
        }
        undoCards();
        matchCounter++;
        matchesMessage.textContent = matchCounter + " Matches";
        if (matchCounter >= cards.length / 2) {
            winningMessage.style.display = "block";
            document.getElementById("moveMessageFinal").textContent =
                "You won in " + moveTracker + " moves!";
            highscoreKey = "memoryHighscore_" + difficulty;
            if (highscore === 0 || moveTracker < highscore) {
                highscore = moveTracker;
                localStorage.setItem(highscoreKey, highscore.toString());
            }
            highscoreMessage.textContent = "Highscore: " + highscore;
        }
    }
    else {
        setTimeout(() => {
            undoClicked();
            // PLAYER SWITCH
            if (multiplayer) {
                currentPlayer = currentPlayer === 1 ? 2 : 1;
                currentPlayerUI.textContent = "Player " + currentPlayer;
            }
        }, 800);
    }
}
//MULTIPLAYER SCORE UPDATE
function updateScores() {
    scoreP1UI.textContent = "Player 1: " + scoreP1;
    scoreP2UI.textContent = "Player 2: " + scoreP2;
}
//KARTEN WERDEN WIEDER UMGEDREHT
function undoClicked() {
    if (flippedCards[0]) {
        flippedCards[0].classList.remove("flipped");
        flippedCards[0].innerHTML = "";
    }
    if (flippedCards[1]) {
        flippedCards[1].classList.remove("flipped");
        flippedCards[1].innerHTML = "";
    }
    undoCards();
}
function undoCards() {
    flippedCards = [];
    checkMatchProcess = 0;
}
//BUTTON NEUES GAME
document.getElementById("newGame").addEventListener("click", resetGame);
document.getElementById("newGame2").addEventListener("click", resetGame);
function resetGame() {
    checkMatchProcess = 0;
    flippedCards = [];
    moveTracker = 0;
    matchCounter = 0;
    currentPlayer = 1;
    scoreP1 = 0;
    scoreP2 = 0;
    updateScores();
    moveMessage.textContent = "0 Moves";
    matchesMessage.textContent = "0 Matches";
    winningMessage.style.display = "none";
    if (multiplayer) {
        currentPlayerUI.textContent = "Player 1";
    }
    const allBoardCards = document.querySelectorAll(".card");
    allBoardCards.forEach(card => {
        card.classList.remove("matched");
        card.textContent = "";
    });
    setupGame();
}
setupGame();
export {};
//# sourceMappingURL=script.js.map